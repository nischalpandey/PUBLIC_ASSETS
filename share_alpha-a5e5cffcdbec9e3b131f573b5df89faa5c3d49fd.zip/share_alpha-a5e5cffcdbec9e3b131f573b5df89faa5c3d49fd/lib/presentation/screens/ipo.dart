import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

class IPO extends StatefulWidget {
  @override
  _IPOState createState() => _IPOState();
}

class _IPOState extends State<IPO> {
  var companyList;

  var boid;
  var selectedCompanyId;
  var result;
  //method to get companies list
  getCompanyData() async {
    final response = await http.get(Uri.parse(
        'https://iporesult.cdsc.com.np/result/companyShares/fileUploaded'));

    setState(() {
      companyList = jsonDecode(response.body.toString());
    });
  }

  //method to send check result request and get result response
  Future checkResult(shareId, bo) async {
    const String resultAPI =
        "https://iporesult.cdsc.com.np/result/result/check";
    final response = await http.post(Uri.parse(resultAPI),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(
            <String, String>{"companyShareId": "$shareId", "boid": "$bo"}));

    var jsonData;
    setState(() {
      if (response.statusCode == 200) {
        jsonData = json.decode(response.body);
        result = jsonData["message"];
      }
    });

    print(response.statusCode);
    print(jsonData.runtimeType);
  }

  bool slect = false;
  //running method to get company details as program runs
  @override
  void initState() {
    getCompanyData();
    super.initState();
    getCompanyData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("View IPO Result"),
      ),
      body: Center(
        child: Column(
          children: [
            (slect == true)
                ? Expanded(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        (companyList == null)
                            ? Column(
                                children: const [
                                  SizedBox(
                                    height: 30,
                                  ),
                                  CircularProgressIndicator(),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Text("Loading Company List")
                                ],
                              )
                            : Expanded(
                                child: ListView.separated(
                                    separatorBuilder: (context, index) {
                                      return const Divider();
                                    },
                                    itemCount: companyList['body']
                                            ['companyShareList']
                                        .length,
                                    itemBuilder: (context, index) {
                                      return ListTile(
                                          onTap: () {
                                            setState(() {
                                              slect = true;
                                            });
                                            checkResult(
                                                companyList['body']
                                                        ['companyShareList'][
                                                    companyList['body'][
                                                                'companyShareList']
                                                            .length -
                                                        (index + 1)]['id'],
                                                1234567890123456);
                                          },
                                          leading: Text((index + 1).toString()),
                                          title: Text(companyList['body']
                                                      ['companyShareList'][
                                                  companyList['body'][
                                                              'companyShareList']
                                                          .length -
                                                      (index + 1)]['scrip']
                                              .toString()),
                                          subtitle: Text(
                                            companyList['body']
                                                        ['companyShareList'][
                                                    companyList['body'][
                                                                'companyShareList']
                                                            .length -
                                                        (index + 1)]['name']
                                                .toString(),
                                          ),
                                          trailing: (index == 0 || index == 1)
                                              ? const Text(
                                                  "New",
                                                  style: TextStyle(
                                                      color: Colors.orange),
                                                )
                                              : null);
                                    }),
                              ),
                      ],
                    ),
                  )
                :
                //boid ui

                Padding(
                    padding: const EdgeInsets.only(left: 40, right: 40),
                    child: TextField(
                      keyboardType: TextInputType.number,
                      onChanged: (value) {
                        setState(() {
                          boid = value;
                        });
                      },
                      onSubmitted: (value) {
                        setState(() {
                          slect = true;
                          boid = value;
                        });
                      },
                      decoration: const InputDecoration(
                        hintText: "Enter your 13 digits BOID",
                      ),
                    ),
                  ),
            const SizedBox(
              height: 30,
            ),

            const SizedBox(height: 20),

            //response of check result below

            result == null ? Container() : Text("$result"),
            const SizedBox(
              height: 5,
            ),
            GestureDetector(
              child: const Text("Not Working Click here"),
              onTap: () {
                launch("https://iporesult.cdsc.com.np/");
              },
            ),
          ],
        ),
      ),
    );
  }
}
