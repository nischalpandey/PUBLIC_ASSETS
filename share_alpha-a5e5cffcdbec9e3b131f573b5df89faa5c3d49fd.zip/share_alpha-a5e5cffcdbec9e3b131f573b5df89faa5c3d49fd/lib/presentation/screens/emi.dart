import 'package:flutter/material.dart';

class EMI extends StatelessWidget {
  const EMI({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("EMI Calculator")),
      body: SingleChildScrollView(
        child: Column(
          children: const [Text("")],
        ),
      ),
    );
  }
}
