import 'package:flutter/material.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';

class WebviewPage extends StatefulWidget {
  final name;
  final link;
  const WebviewPage({Key? key, this.link, this.name}) : super(key: key);

  @override
  State<WebviewPage> createState() => _WebviewPageState();
}

@override
class _WebviewPageState extends State<WebviewPage> {
  late WebViewController _controller;
  late BannerAd _bannerAd;
  bool isBannerLoad = false;
  var loadprogress = 0;

  _bannerad() {
    _bannerAd = BannerAd(
        size: AdSize.banner,
        adUnitId: "ca-app-pub-1764646806293143/2935318128",
        listener: BannerAdListener(
          onAdLoaded: (ad) {
            setState(() {
              isBannerLoad = true;
            });
          },
        ),
        request: const AdRequest());
    _bannerAd.load();
  }

  bool isweloaded = true;
  final _key = UniqueKey();

  @override
  void initState() {
    super.initState();
    _bannerad();
  }

  @override
  Widget build(BuildContext context) => WillPopScope(
        child: Scaffold(
          appBar: AppBar(
            title: Text(widget.name ?? "ShareAlpha"),
            toolbarHeight: 40,
          ),
          bottomNavigationBar: (isBannerLoad == true)
              ? SizedBox(
                  height: _bannerAd.size.height.toDouble(),
                  width: _bannerAd.size.width.toDouble(),
                  child: AdWidget(ad: _bannerAd),
                )
              : GestureDetector(
                  onTap: () {
                    launch("mailto:hello@nischalpandey.com.np");
                  },
                  child: SizedBox(
                    height: _bannerAd.size.height.toDouble(),
                    width: _bannerAd.size.width.toDouble(),
                    child: const Center(child: Text("Advertise with us")),
                  ),
                ),
          body: Column(
            children: [
              Expanded(
                child: WebView(
                  key: _key,
                  initialUrl: widget.link ?? "https://nepsealpha.com/",
                  zoomEnabled: false,
                  onProgress: (progress) {
                    setState(() {
                      loadprogress = progress;
                    });
                  },
                  javascriptMode: JavascriptMode.unrestricted,
                  onWebViewCreated: (WebViewController webViewController) {
                    _controller = webViewController;
                    _controller.clearCache();
                    CookieManager().clearCookies();
                    if (widget.name == "Bulk IPO Apply - Share Alpha") {
                      showDialog(
                        context: context,
                        builder: (ctx) => AlertDialog(
                          title: const Text("Alert Dialog Box"),
                          content:
                              const Text("You have raised a Alert Dialog Box"),
                          actions: <Widget>[
                            TextButton(
                              onPressed: () {
                                Navigator.of(ctx).pop();
                              },
                              child: Container(
                                color: Colors.green,
                                padding: const EdgeInsets.all(14),
                                child: const Text("okay"),
                              ),
                            ),
                          ],
                        ),
                      );
                    }
                  },
                  onPageFinished: (url) {
                    if (url == "https://www.sharesansar.com/emi-calculator") {
                      _controller.runJavascript(
                          "document.getElementsByTagName('footer')[0].style.display='none';");
                      _controller.runJavascript(
                          "document.getElementsByTagName('header')[0].style.display='none';");
                      _controller.runJavascript(
                          "document.getElementsByClassName('outer-footer')[0].style.display='none';;");
                      _controller.runJavascript(
                          "document.getElementsByTagName('section')[0].style.display='none';");
                    }
                    _controller.runJavascript(
                        "document.getElementsByClassName('mobile_menu_container')[0].style.display='none';");
                    _controller.runJavascript(
                        "document.getElementsByClassName('header clearfix')[0].style.display='none';");
                    _controller.runJavascript(
                        "document.getElementsByClassName('footer_container')[0].style.display='none';");
                    setState(() {
                      isweloaded = true;
                    });
                  },
                  onPageStarted: (url) {
                    Future.delayed(const Duration(seconds: 1), () {
                      _controller.runJavascript(
                          "document.getElementsByClassName('header clearfix')[0].style.display='none';");
                      _controller.runJavascript(
                          "document.getElementsByClassName('footer_container')[0].style.display='none';");
                      _controller.runJavascript(
                          "document.getElementsByClassName('mobile_menu_container')[0].style.display='none';");
                    });
                    Future.delayed(const Duration(seconds: 2), () {
                      _controller.runJavascript(
                          "document.getElementsByClassName('header clearfix')[0].style.display='none';");
                      _controller.runJavascript(
                          "document.getElementsByClassName('mobile_menu_container')[0].style.display='none';");
                    });
                    Future.delayed(const Duration(seconds: 3), () {
                      if (url == "https://www.sharesansar.com/emi-calculator") {
                        _controller.runJavascript(
                            "document.getElementsByTagName('footer')[0].style.display='none';");
                        _controller.runJavascript(
                            "document.getElementsByTagName('header')[0].style.display='none';");
                        _controller.runJavascript(
                            "document.getElementsByClassName('outer-footer')[0].style.display='none';;");
                        _controller.runJavascript(
                            "document.getElementsByTagName('section')[0].style.display='none';");
                      }
                      _controller.runJavascript(
                          "document.getElementsByClassName('mobile_menu_container')[0].style.display='none';");
                      _controller.runJavascript(
                          "document.getElementsByClassName('header clearfix')[0].style.display='none';");
                      _controller.runJavascript(
                          "document.getElementsByClassName('footer_container')[0].style.display='none';");
                    });
                  },
                  backgroundColor:
                      Theme.of(context).bannerTheme.backgroundColor,
                  navigationDelegate: (NavigationRequest request) {
                    if (request.url.contains("https://play.google.com/") ||
                        request.url.contains("https://www.facebook.com/")) {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                        content: Text("Access Denied"),
                        duration: Duration(milliseconds: 800),
                      ));
                      return NavigationDecision.prevent;
                    }

                    return NavigationDecision.navigate;
                  },
                ),
              ),
              LinearProgressIndicator(
                minHeight: 1,
                color: Colors.green,
                value: loadprogress / 100,
                backgroundColor: Theme.of(context).bannerTheme.backgroundColor,
              ),
            ],
          ),
        ),
        onWillPop: () async {
          if (await _controller.canGoBack()) {
            _controller.goBack();
            return false;
          } else {
            return true;
          }
        },
      );
}
