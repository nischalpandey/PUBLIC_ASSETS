import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:nepali_utils/nepali_utils.dart';

class Unicode extends StatefulWidget {
  const Unicode({Key? key}) : super(key: key);

  @override
  State<Unicode> createState() => _UnicodeState();
}

class _UnicodeState extends State<Unicode> {
  String values = " Nepali Unicode";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Nepali Unicode"),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          ListTile(
            leading: IconButton(
                onPressed: () {
                  Clipboard.setData(ClipboardData(text: values));
                  ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text("Text Copied")));
                },
                icon: const Icon(Icons.copy)),
            title: SelectableText(values),
            trailing: GestureDetector(
              child: const Icon(Icons.delete),
              onTap: () {
                setState(() {
                  values = "";
                });
              },
            ),
          ),
          TextField(
            maxLines: 8,
            decoration: InputDecoration(
                border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(color: Colors.grey)),
                hintText: "Enter here"),
            onChanged: (value) {
              setState(() {
                values = NepaliUnicode.convert(value, live: true).toString();
              });
            },
          ),
        ],
      ),
    );
  }
}
