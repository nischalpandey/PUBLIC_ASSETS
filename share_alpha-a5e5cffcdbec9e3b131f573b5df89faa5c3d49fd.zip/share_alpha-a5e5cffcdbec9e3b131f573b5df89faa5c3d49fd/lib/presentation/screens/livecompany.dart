import 'dart:async';

import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:flutter/material.dart';
import 'package:html/parser.dart';
import 'package:http/http.dart' as http;
import 'package:html/dom.dart' as dom;

class Companylive extends StatefulWidget {
  const Companylive({
    Key? key,
  }) : super(key: key);

  @override
  State<Companylive> createState() => _CompanyliveState();
}

class _CompanyliveState extends State<Companylive> {
  List<String> company = [
    "loading",
    "loading",
    "loading",
    "No company",
    "No company",
    "No company",
    "No company",
    "No company",
    "No company",
  ];

  List<String> nepse = [
    "Nepse..",
    "",
    "",
    "",
    "",
    "",
  ];

  Future getData() async {
    final response =
        await http.get(Uri.parse("http://nepalstock.com/stocklive"));
    dom.Document html = parse(response.body);
    final compan = html
        .querySelectorAll(".table-condensed")[0]
        .querySelectorAll("table > tbody > tr > td");
    final nep = html.querySelectorAll("#banner")[0].querySelectorAll('div');

    setState(() {
      nepse = nep.map((element) => element.text.trim()).toList();
      company = compan.map((element) => element.text.trim()).toList();
    });
  }

  getData2() {
    print("object");
  }

  @override
  void initState() {
    super.initState();
    getData();
    Timer.periodic(const Duration(seconds: 35), (timer) {
      //code to run on every 2 minutes 5 seconds

      getData();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          toolbarHeight: 70,
          title: Column(
            children: [
              Row(
                children: [
                  const SizedBox(
                    width: 10,
                  ),
                  const Icon(
                    Icons.circle,
                    size: 16,
                    color: Colors.red,
                  ),
                  AnimatedTextKit(
                    animatedTexts: [
                      ColorizeAnimatedText("Live Market Data",
                          textStyle: const TextStyle(fontSize: 20),
                          colors: [
                            Colors.red,
                            Colors.greenAccent,
                            Colors.purple,
                          ]),
                    ],
                    isRepeatingAnimation: true,
                    repeatForever: true,
                  ),
                ],
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    (nepse.length > 1) ? nepse[1] : nepse[0],
                    style: TextStyle(
                        fontSize: 14,
                        color: (nepse[4].contains("-"))
                            ? Colors.red
                            : Colors.green),
                  ),
                  Text(
                    (nepse.length > 1) ? nepse[2] : "",
                    style: TextStyle(
                        fontSize: 14,
                        color: (nepse[4].contains("-"))
                            ? Colors.red
                            : Colors.green),
                  ),
                  Text(
                    (nepse.length > 1) ? nepse[3] : "",
                    style: TextStyle(
                        fontSize: 14,
                        color: (nepse[4].contains("-"))
                            ? Colors.red
                            : Colors.green),
                  ),
                  Text(
                    (nepse.length > 1) ? nepse[4] : "",
                    style: TextStyle(
                        fontSize: 14,
                        color: (nepse[4].contains("-"))
                            ? Colors.red
                            : Colors.green),
                  ),
                ],
              ),
            ],
          )),
      body: (company.length < 20)
          ? Center(
              child: CircularProgressIndicator(
                color: Theme.of(context).appBarTheme.backgroundColor,
              ),
            )
          : RefreshIndicator(
              onRefresh: getData,
              child: Column(
                children: [
                  Container(
                    color: Colors.blue,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: const [
                        Text(
                          "  S.n    ",
                          style: TextStyle(fontSize: 14),
                        ),
                        Text(
                          "Symbol",
                          style: TextStyle(fontSize: 14),
                        ),
                        Text("LTP", style: TextStyle(fontSize: 14)),
                        Text("Point Change", style: TextStyle(fontSize: 14)),
                        Text("Prv Closing", style: TextStyle(fontSize: 14)),
                      ],
                    ),
                  ),
                  const SizedBox(
                    height: 3,
                  ),
                  Expanded(
                    child: ListView.separated(
                        shrinkWrap: true,
                        itemBuilder: (context, index) {
                          return GestureDetector(
                            onTap: () {
                              showModalBottomSheet(
                                  context: context,
                                  builder: (builder) {
                                    return Container(
                                      decoration: BoxDecoration(
                                        color: (company[11 * index + 4]
                                                .contains("-"))
                                            ? Colors.red
                                            : (company[11 * index + 4] ==
                                                    '0.00')
                                                ? Colors.blue
                                                : Colors.green,
                                        border: Border.all(
                                          color: const Color.fromARGB(
                                              255, 124, 56, 225),
                                        ),
                                      ),
                                      height:
                                          MediaQuery.of(context).size.height *
                                              0.30,

                                      // ignore: prefer_const_constructors
                                      child: Column(
                                        children: [
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceBetween,
                                            children: [
                                              Text(company[11 * index + 1],
                                                  textScaleFactor: 2,
                                                  style: const TextStyle(
                                                      fontWeight:
                                                          FontWeight.bold)),
                                              Text(
                                                  "LTP" +
                                                      company[11 * index + 2],
                                                  textScaleFactor: 2,
                                                  style: const TextStyle(
                                                      fontWeight:
                                                          FontWeight.bold)),
                                            ],
                                          ),
                                          const Divider(),
                                          Container(
                                            color: Theme.of(context)
                                                .bannerTheme
                                                .backgroundColor,
                                            child: Column(
                                              children: [
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: const [
                                                    Text(
                                                      "LTV",
                                                      textScaleFactor: 1.5,
                                                    ),
                                                    Text("Point change",
                                                        textScaleFactor: 1.5),
                                                    Text("%Change",
                                                        textScaleFactor: 1.5),
                                                    Text("Open",
                                                        textScaleFactor: 1.5),
                                                  ],
                                                ),
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Text(
                                                        company[11 * index + 3],
                                                        textScaleFactor: 1.5),
                                                    Text(
                                                        company[11 * index + 4],
                                                        textScaleFactor: 1.5),
                                                    Text(
                                                        company[11 * index + 5],
                                                        textScaleFactor: 1.5),
                                                    Text(
                                                        company[11 * index + 6],
                                                        textScaleFactor: 1.5),
                                                  ],
                                                )
                                              ],
                                            ),
                                          ),
                                          const SizedBox(
                                            height: 20,
                                          ),
                                          Container(
                                            color: Theme.of(context)
                                                .bannerTheme
                                                .backgroundColor,
                                            child: Column(
                                              children: [
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: const [
                                                    Text(
                                                      "High",
                                                      textScaleFactor: 1.5,
                                                    ),
                                                    Text("Low",
                                                        textScaleFactor: 1.5),
                                                    Text("Volume",
                                                        textScaleFactor: 1.5),
                                                    Text("Prev.Closing",
                                                        textScaleFactor: 1.5),
                                                  ],
                                                ),
                                                Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Text(
                                                        company[11 * index + 7],
                                                        textScaleFactor: 1.5),
                                                    Text(
                                                        company[11 * index + 8],
                                                        textScaleFactor: 1.5),
                                                    Text(
                                                        company[11 * index + 9],
                                                        textScaleFactor: 1.5),
                                                    Text(
                                                        company[
                                                            11 * index + 10],
                                                        textScaleFactor: 1.5),
                                                  ],
                                                )
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    );
                                  });
                            },
                            child: ListTile(
                              tileColor: (company[11 * index + 4].contains("-"))
                                  ? Colors.red
                                  : (company[11 * index + 4] == '0.00')
                                      ? Colors.blue
                                      : Colors.green,
                              title: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    company[11 * index + 1],
                                  ),
                                  Text(
                                    company[11 * index + 2],
                                  ),
                                  Text(
                                    company[11 * index + 4],
                                  ),
                                  Text(
                                    company[11 * index + 10],
                                  ),
                                ],
                              ),
                              leading: Text((index + 1).toString()),
                            ),
                          );
                        },
                        separatorBuilder: (context, index) {
                          return const Divider();
                        },
                        itemCount: company.length ~/ 11),
                  ),
                ],
              ),
            ),
    );
  }
}
