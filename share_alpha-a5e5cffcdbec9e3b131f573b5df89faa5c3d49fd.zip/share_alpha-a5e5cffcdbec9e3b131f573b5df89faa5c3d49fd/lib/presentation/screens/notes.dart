import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Note extends StatefulWidget {
  const Note({Key? key}) : super(key: key);

  @override
  State<Note> createState() => _NoteState();
}

class _NoteState extends State<Note> {
  var data = '';
  String note = '';
  setname(note) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    pref.setString("note", note);
  }

  @override
  void initState() {
    cheakname();

    super.initState();
  }

  cheakname() async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    setState(() {
      note = pref.getString("note") ?? "No Notes (click here to write)";
    });
  }

  bool hide = true;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("My Notes"),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            ElevatedButton(
                onPressed: () async {
                  SharedPreferences pref =
                      await SharedPreferences.getInstance();
                  pref.remove('note');
                  cheakname();
                },
                child: const Text('Delates Notes')),
            const SizedBox(
              height: 10,
            ),
            GestureDetector(
              onTap: () {
                setState(() {
                  hide = false;
                });
              },
              child: Container(
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                      color: Theme.of(context).bannerTheme.backgroundColor,
                      border: Border.all(
                        color: const Color.fromARGB(255, 124, 56, 225),
                      ),
                      borderRadius: BorderRadius.circular(2)),
                  child: Text(
                    note,
                    style: GoogleFonts.roboto(fontSize: 20),
                  )),
            ),
            (hide == false)
                ? TextField(
                    maxLines: 5,
                    decoration: InputDecoration(
                        hintText: 'Write here',
                        suffix: IconButton(
                            onPressed: () {
                              setname(note);
                              setState(() {
                                hide = true;
                              });
                            },
                            icon: const Icon(Icons.save))),
                    onChanged: (value) {
                      setState(() {
                        note = value;
                      });
                    },
                    onSubmitted: (value) async {
                      setname(value);
                      setState(() {
                        hide = true;
                      });
                    })
                : Container(
                    height: 1,
                  )
          ],
        ),
      ),
    );
  }
}
