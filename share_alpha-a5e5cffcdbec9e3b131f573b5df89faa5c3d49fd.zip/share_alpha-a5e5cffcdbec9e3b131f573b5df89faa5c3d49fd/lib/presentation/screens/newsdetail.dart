import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:html/parser.dart';
import 'package:http/http.dart' as http;
import 'package:html/dom.dart' as dom;
import 'package:url_launcher/url_launcher.dart';

class Newsdetail extends StatefulWidget {
  final link;
  final img;
  final tittle;
  const Newsdetail({
    Key? key,
    this.link,
    this.img,
    this.tittle,
  }) : super(key: key);

  @override
  State<Newsdetail> createState() => _NewsdetailState();
}

class _NewsdetailState extends State<Newsdetail> {
  List<String> news = [
    "getting...",
  ];

  getnewsdeatail() async {
    final response = await http.get(Uri.parse(widget.link));
    dom.Document html = parse(response.body);

    final nep =
        html.querySelectorAll(".divNewsDetailSec")[0].querySelectorAll("div");
    setState(() {
      news = nep
          .map((element) => element.text
              .trim()
              .toString()
              .replaceAll("नेपाली पैसा", "Powered Share Alpha"))
          .toList();
    });
  }

  @override
  void initState() {
    getnewsdeatail();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.tittle.toString()),
        toolbarHeight: 40,
      ),
      body: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 20.0),
              child: Text(
                widget.tittle,
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Image.network(
              widget.img,
              width: MediaQuery.of(context).size.width * 0.9,
              fit: BoxFit.cover,
            ),
            (news[0] == "getting...")
                ? const Padding(
                    padding: EdgeInsets.all(40.0),
                    child: Center(child: CircularProgressIndicator()),
                  )
                : Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(
                            left: 10.0, right: 10.0, top: 20),
                        child: Text(
                          news[0],
                          style: GoogleFonts.aBeeZee(
                            fontSize: 20,
                          ),
                        ),
                      ),
                      GestureDetector(
                        onTap: () {
                          launch(
                              'https://play.google.com/store/apps/details?id=com.nepalstock.alpha');
                        },
                        child: Container(
                          decoration: BoxDecoration(
                              border: Border.all(color: Colors.blue)),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: const [
                              Icon(
                                Icons.facebook,
                                color: Colors.purple,
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              Icon(
                                Icons.messenger,
                                color: Colors.purple,
                              ),
                              SizedBox(
                                width: 5,
                              ),
                              Icon(
                                Icons.share,
                                color: Colors.purple,
                              ),
                              SizedBox(
                                width: 5,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
          ],
        ),
      ),
    );
  }
}
