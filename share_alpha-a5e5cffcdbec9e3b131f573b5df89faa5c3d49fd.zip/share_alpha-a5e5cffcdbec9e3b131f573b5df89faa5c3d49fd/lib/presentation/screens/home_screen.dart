import 'dart:async';
import 'dart:convert';
import 'package:onesignal_flutter/onesignal_flutter.dart';
import 'package:api_cache_manager/api_cache_manager.dart';
import 'package:api_cache_manager/models/cache_db_model.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:html/parser.dart';
import 'package:http/http.dart' as http;
import 'package:html/dom.dart' as dom;
import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:nepali_utils/nepali_utils.dart';

import 'package:provider/provider.dart';
import 'package:share_alpha/data/dataproviders/dates.dart';
import 'package:share_alpha/presentation/screens/about.dart';

import 'package:share_alpha/presentation/screens/company.dart';
import 'package:share_alpha/presentation/screens/ipo.dart';
import 'package:share_alpha/presentation/screens/livecompany.dart';
import 'package:share_alpha/presentation/screens/news.dart';
import 'package:share_alpha/presentation/screens/notes.dart';
import 'package:share_alpha/presentation/screens/unicode.dart';

import 'package:share_alpha/presentation/screens/webview.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../data/models/theme_model.dart';
import '../widgets/features.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<String> market = [
    "Market...",
  ];
  List<String> date = [
    "As of ...",
  ];
  List<String> indexinfo = [
    "index....",
    "index....",
  ];
  List<String> inorde = [
    "load",
  ];
  List<String> marketsum = [
    "load",
  ];
  List<String> topgainer = [
    "load",
  ];
  List<String> toplosser = [
    "load",
  ];
  List<String> topshares = [
    "load",
    "loading",
  ];
  var notifi;

  String nepse = "";
  bool isDark = false;
  // getData2() async {
  //   final response =
  //       await http.get(Uri.parse("https://www.nepalipaisa.com/Home.aspx"));
  //   dom.Document html = parse(response.body);

  //   final marketinfo = html.querySelectorAll("#marketStatus");
  //   final dat = html.querySelectorAll(".divMarketStatTicker");

  //   // final indexfo = html.querySelectorAll(".table-responsive");
  //   // final inordeimg = html
  //   //     .querySelectorAll(".table-condensed")[9]
  //   //     .querySelectorAll("table > tbody > tr > td > img");
  //   // //marker sumary....
  //   // final marketso = html
  //   //     .querySelectorAll(".table-condensed")[8]
  //   //     .querySelectorAll("tbody > tr > td");
  //   // final topgain = html
  //   //     .querySelectorAll(".table-condensed")[3]
  //   //     .querySelectorAll("tbody > tr > td");lue)
  //   // final toploss = html
  //   //     .querySelectorAll(".table-condensed")[4]
  //   //     .querySelectorAll("tbody > tr > td");
  //   // final topshare = html
  //   //     .querySelectorAll(".table-condensed")[1]
  //   //     .querySelectorAll("tbody > tr > td");

  //   setState(() {
  //     //indexinfo = indexfo.map((element) => element.text.trim()).toList();
  //     date = dat.map((element) => element.text.trim()).toList();

  //     // inorde = inordeimg.map((element) => element.attributes['src']!).toList();
  //     // topgainer = topgain.map((element) => element.text.trim()).toList();
  //     // toplosser = toploss.map((element) => element.text.trim()).toList();
  //     // topshares = topshare.map((element) => element.text.trim()).toList();
  //     // marketsum = marketso.map((element) => element.text.trim()).toList();
  //     market = marketinfo.map((element) => element.text.trim()).toList();
  //   });
  //   print('feom get 2');
  // }
  bool code = true;
  getnoti() async {
    final response =
        await http.get(Uri.parse("http://www.ngp.com.np/sharealpha"));
    if (response.statusCode == 200) {
      setState(() {
        notifi = jsonDecode(response.body.toString());
      });
    }
  }

  Future getData() async {
    var isData = await APICacheManager().isAPICacheKeyExist("offdata");

    final response = await http
        .get(Uri.parse("http://nepalstock.com/"))
        .timeout(const Duration(seconds: 22), onTimeout: () {
      return http.Response('Error', 500);
    });

    if (response.statusCode == 200) {
      dom.Document html = parse(response.body);

      APICacheDBModel cacheDBModel =
          APICacheDBModel(key: "offdata", syncData: response.body);
      await APICacheManager().addCacheData(cacheDBModel);

      final marketinfo = html.querySelectorAll("#top-notice-bar");
      final dat = html.querySelectorAll("#date");

      final indexfo = html
          .querySelectorAll(".table-condensed")[9]
          .querySelectorAll("table > tbody > tr > td");

      final inordeimg = html
          .querySelectorAll(".table-condensed")[9]
          .querySelectorAll("table > tbody > tr > td > img");
      //marker sumary....
      final marketso = html
          .querySelectorAll(".table-condensed")[8]
          .querySelectorAll("tbody > tr > td");
      final topgain = html
          .querySelectorAll(".table-condensed")[3]
          .querySelectorAll("tbody > tr > td");
      final toploss = html
          .querySelectorAll(".table-condensed")[4]
          .querySelectorAll("tbody > tr > td");
      final topshare = html
          .querySelectorAll(".table-condensed")[1]
          .querySelectorAll("tbody > tr > td");

      setState(() {
        indexinfo = indexfo.map((element) => element.text.trim()).toList();
        date = dat.map((element) => element.text.trim()).toList();

        inorde =
            inordeimg.map((element) => element.attributes['src']!).toList();
        topgainer = topgain.map((element) => element.text.trim()).toList();
        toplosser = toploss.map((element) => element.text.trim()).toList();
        topshares = topshare.map((element) => element.text.trim()).toList();
        marketsum = marketso.map((element) => element.text.trim()).toList();
        market = marketinfo.map((element) => element.text.trim()).toList();
      });
    } else {
      var casData = await APICacheManager().getCacheData("offdata");

      dom.Document html = parse(casData.syncData);

      final marketinfo = html.querySelectorAll("#top-notice-bar");
      final dat = html.querySelectorAll("#date");

      final indexfo = html
          .querySelectorAll(".table-condensed")[9]
          .querySelectorAll("table > tbody > tr > td");

      final inordeimg = html
          .querySelectorAll(".table-condensed")[9]
          .querySelectorAll("table > tbody > tr > td > img");
      //marker sumary....
      final marketso = html
          .querySelectorAll(".table-condensed")[8]
          .querySelectorAll("tbody > tr > td");
      final topgain = html
          .querySelectorAll(".table-condensed")[3]
          .querySelectorAll("tbody > tr > td");
      final toploss = html
          .querySelectorAll(".table-condensed")[4]
          .querySelectorAll("tbody > tr > td");
      final topshare = html
          .querySelectorAll(".table-condensed")[1]
          .querySelectorAll("tbody > tr > td");

      setState(() {
        indexinfo = indexfo.map((element) => element.text.trim()).toList();
        date = dat.map((element) => element.text.trim()).toList();

        inorde =
            inordeimg.map((element) => element.attributes['src']!).toList();
        topgainer = topgain.map((element) => element.text.trim()).toList();
        toplosser = toploss.map((element) => element.text.trim()).toList();
        topshares = topshare.map((element) => element.text.trim()).toList();
        marketsum = marketso.map((element) => element.text.trim()).toList();
        market = marketinfo
            .map((element) =>
                element.text.trim().replaceAll('Market Open', 'Market..'))
            .toList();
      });

      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text("Nepse Server error while fetching new data..."),
        action: SnackBarAction(
          onPressed: () {
            launch("https://nepalstock.com.np/");
          },
          label: "Open web",
        ),
      ));
    }
  }

  // getnew() async {
  //   final response =
  //       await http.get(Uri.parse("https://www.nepalstock.com.np/"));
  //   dom.Document dta = parse(response.body);
  //   setState(() {
  //     dataho = response.body.toString();
  //   });
  // }

  //market info..........
  String livetime = NepaliDateFormat("h:m:s a", Language.nepali)
      .format(NepaliDateTime.parse(NepaliDateTime.now().toIso8601String()));

  late BannerAd _bannerAd;
  bool isBannerLoad = false;

  _bannerad() {
    _bannerAd = BannerAd(
        size: AdSize.largeBanner,
        adUnitId: "ca-app-pub-1764646806293143/2935318128",
        listener: BannerAdListener(
          onAdLoaded: (ad) {
            setState(() {
              isBannerLoad = true;
            });
          },
        ),
        request: const AdRequest());
    _bannerAd.load();
  }

  InterstitialAd? _interstitialAd;

  void loadInterstitialAd() {
    InterstitialAd.load(
        adUnitId: "ca-app-pub-1764646806293143/3408276633",
        request: const AdRequest(),
        adLoadCallback: InterstitialAdLoadCallback(
          onAdLoaded: (InterstitialAd ad) {
            // Keep a reference to the ad so you can show it later.
            _interstitialAd = ad;

            ad.fullScreenContentCallback = FullScreenContentCallback(
              onAdDismissedFullScreenContent: (InterstitialAd ad) {
                ad.dispose();
                loadInterstitialAd();
              },
              onAdFailedToShowFullScreenContent:
                  (InterstitialAd ad, AdError error) {
                ad.dispose();
                loadInterstitialAd();
              },
            );
          },
          onAdFailedToLoad: (LoadAdError error) {
            print('InterstitialAd failed to load: $error');
          },
        ));
  }

  var status = 0;
  final Connectivity _connectivity = Connectivity();
  void checkConnectivity() async {
    var connectionResult = await _connectivity.checkConnectivity();

    if (connectionResult == ConnectivityResult.mobile) {
      status = 1;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        duration: Duration(milliseconds: 800),
        content: Text("MobileData Connectivity found."),
      ));
    } else if (connectionResult == ConnectivityResult.wifi) {
      status = 2;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text("wifi Connectivity found."),
        duration: Duration(milliseconds: 800),
      ));
    } else {
      var casData = await APICacheManager().getCacheData("offdata");

      dom.Document html = parse(casData.syncData);

      final marketinfo = html.querySelectorAll("#top-notice-bar");
      final dat = html.querySelectorAll("#date");

      final indexfo = html
          .querySelectorAll(".table-condensed")[9]
          .querySelectorAll("table > tbody > tr > td");

      final inordeimg = html
          .querySelectorAll(".table-condensed")[9]
          .querySelectorAll("table > tbody > tr > td > img");
      //marker sumary....
      final marketso = html
          .querySelectorAll(".table-condensed")[8]
          .querySelectorAll("tbody > tr > td");
      final topgain = html
          .querySelectorAll(".table-condensed")[3]
          .querySelectorAll("tbody > tr > td");
      final toploss = html
          .querySelectorAll(".table-condensed")[4]
          .querySelectorAll("tbody > tr > td");
      final topshare = html
          .querySelectorAll(".table-condensed")[1]
          .querySelectorAll("tbody > tr > td");

      setState(() {
        indexinfo = indexfo.map((element) => element.text.trim()).toList();
        date = dat.map((element) => element.text.trim()).toList();

        inorde =
            inordeimg.map((element) => element.attributes['src']!).toList();
        topgainer = topgain.map((element) => element.text.trim()).toList();
        toplosser = toploss.map((element) => element.text.trim()).toList();
        topshares = topshare.map((element) => element.text.trim()).toList();
        marketsum = marketso.map((element) => element.text.trim()).toList();
        market = marketinfo
            .map((element) =>
                element.text.trim().replaceAll("Market Open", "Market..."))
            .toList();
      });

      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: const Text("No internet found. Unable to load new data"),
        action: SnackBarAction(
          onPressed: () {},
          label: "OK",
        ),
      ));
    }
    setState(() {});
  }

  void disposeAds() {
    _interstitialAd?.dispose();
  }

  @override
  void initState() {
    checkConnectivity();
    getData();
    // getnew();

    Timer.periodic(const Duration(seconds: 1), (timer) {
      //code to run on every 2 minutes 5 seconds

      setState(() {
        livetime = NepaliDateFormat("h:m:s a", Language.nepali).format(
            NepaliDateTime.parse(NepaliDateTime.now().toIso8601String()));
      });
    });
    getBoolValues() async {
      SharedPreferences prefs = await SharedPreferences.getInstance();
      //Return bool

      setState(() {
        isDark = prefs.getBool('mode') ?? false;
      });
    }

    _bannerad();
    loadInterstitialAd();
    Timer.periodic(const Duration(seconds: 35), (timer) {
      //code to run on every 2 minutes 5 seconds

      getData();
    });
    super.initState();
    myonesignal();
    getnoti();
  }

  List noti = [];
  Future<void> myonesignal() async {
    await OneSignal.shared.setAppId('d07ab179-b019-403b-a817-98b906d2356b');

    OneSignal.shared
        .setNotificationOpenedHandler((OSNotificationOpenedResult result) {
      setState(() {
        noti = jsonDecode(result.toString()).trim() as List;
      });

      Navigator.push(context, MaterialPageRoute(builder: (context) {
        return const News();
      }));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: RefreshIndicator(
        color: Theme.of(context).appBarTheme.backgroundColor,
        onRefresh: getData,
        child: CustomScrollView(
          anchor: 0.0,
          slivers: [
            SliverAppBar(
              elevation: 0,
              title: const Text("Share Alpha"),
              floating: true,
              actions: [
                IconButton(
                    onPressed: () async {
                      final themeProvider =
                          Provider.of<ThemeProvider>(context, listen: false);
                      Provider.of<ThemeProvider>(context, listen: false)
                          .toggleTheme(themeProvider.isDarkMode);
                    },
                    icon: Icon((Provider.of<ThemeProvider>(context).isDarkMode)
                        ? Icons.light_mode_outlined
                        : Icons.dark_mode_outlined)),

                // Message
                IconButton(
                    onPressed: () {
                      _interstitialAd?.show();
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) {
                        return News(
                          nepse: market,
                        );
                      }));
                    },
                    icon: const Icon(Icons.newspaper)),
              ],
            ),
            SliverToBoxAdapter(
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    /*-----------Top Card Views-------------*/
                    topCardView(context),

                    /*-----------Upcoming Events-------------*/
                    const SizedBox(height: 10),
                    indexinfodata(),
                    /*-----------Notification-------------*/
                    const SizedBox(
                      height: 10,
                    ),
                    marketsumdata(),
                    const SizedBox(
                      height: 10,
                    ),
                    notification(context),
                    const SizedBox(height: 10),
                    togainerdata(),
                    const SizedBox(height: 10),
                    tolosserdata(),
                    const SizedBox(height: 10),
                    notification(context),
                    const SizedBox(height: 10),
                    toshare(),
                    const SizedBox(height: 10),
                    /*-----------Hamro Services-------------*/
                    hamroServices(),
                    const SizedBox(
                      height: 10,
                    ),
                    /*-----------Promotions-------------*/
                    promotions(context),

                    /*-----------More Features-------------*/
                    moreFeatures(),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  indexinfodata() {
    return (indexinfo.length > 3)
        ? Container(
            decoration: BoxDecoration(
                color: Theme.of(context).bannerTheme.backgroundColor,
                border: Border.all(
                  color: const Color.fromARGB(255, 124, 56, 225),
                ),
                borderRadius: BorderRadius.circular(8)),
            padding: const EdgeInsets.only(left: 3, right: 3),
            child: Wrap(
              // main axis (rows or columns)
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Index          ",
                        style: GoogleFonts.roboto(
                            fontSize: 14, fontWeight: FontWeight.bold)),
                    Text("Current",
                        style: GoogleFonts.roboto(
                            fontSize: 14, fontWeight: FontWeight.bold)),
                    Text("Points Change",
                        style: GoogleFonts.roboto(
                            fontSize: 14, fontWeight: FontWeight.bold)),
                    Text("%Change",
                        style: GoogleFonts.roboto(
                            fontSize: 14, fontWeight: FontWeight.bold)),
                  ],
                ),
                const Divider(
                  height: 8,
                  color: Colors.green,
                ),
                Container(
                  color: (inorde[0].contains("./images/decrease.gif"))
                      ? Colors.red
                      : Colors.green,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        indexinfo[0],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        indexinfo[1],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        indexinfo[2],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        indexinfo[3],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                    ],
                  ),
                ),
                const Divider(),
                Container(
                  color: (inorde[1].contains("./images/decrease.gif"))
                      ? Colors.red
                      : Colors.green,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        indexinfo[5],
                        style: GoogleFonts.aBeeZee(fontSize: 16),
                      ),
                      Text(
                        indexinfo[6],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        indexinfo[7],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        indexinfo[8],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                    ],
                  ),
                ),
                const Divider(),
                Container(
                  color: (inorde[2].contains("./images/decrease.gif"))
                      ? Colors.red
                      : Colors.green,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        indexinfo[10] + "   ",
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        indexinfo[11],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        indexinfo[12],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        indexinfo[13],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                    ],
                  ),
                ),
                const Divider(),
                Container(
                  color: (inorde[3].contains("./images/decrease.gif"))
                      ? Colors.red
                      : Colors.green,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        indexinfo[15],
                        style: GoogleFonts.aBeeZee(fontSize: 14),
                      ),
                      Text(
                        indexinfo[16],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        indexinfo[17],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        indexinfo[18],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                    ],
                  ),
                ),
                const Divider(),
              ],
            ),
          )
        : Container(
            decoration: BoxDecoration(
                color: Theme.of(context).bannerTheme.backgroundColor,
                border: Border.all(
                  color: const Color.fromARGB(255, 124, 56, 225),
                ),
                borderRadius: BorderRadius.circular(8)),
            child: const Center(
              child: Text("Loading"),
            ),
          );
    /*-----------Notification-------------*/
  }

  marketsumdata() {
    return (marketsum.length > 2)
        ? Container(
            decoration: BoxDecoration(
                color: Theme.of(context).bannerTheme.backgroundColor,
                border: Border.all(
                  color: const Color.fromARGB(255, 124, 56, 225),
                ),
                borderRadius: BorderRadius.circular(8)),
            padding: const EdgeInsets.only(left: 3, right: 3),
            child: Wrap(
              // main axis (rows or columns)
              children: <Widget>[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Market Summary         ",
                        style: GoogleFonts.roboto(
                            fontSize: 22, fontWeight: FontWeight.bold)),
                  ],
                ),
                const Divider(
                  height: 8,
                  color: Colors.green,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      marketsum[0],
                      style: GoogleFonts.aBeeZee(fontSize: 18),
                    ),
                    Text(
                      marketsum[1],
                      style: GoogleFonts.aBeeZee(fontSize: 18),
                    ),
                  ],
                ),
                const Divider(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      marketsum[2],
                      style: GoogleFonts.aBeeZee(fontSize: 16),
                    ),
                    Text(
                      marketsum[3],
                      style: GoogleFonts.aBeeZee(fontSize: 18),
                    ),
                  ],
                ),
                const Divider(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      marketsum[4],
                      style: GoogleFonts.aBeeZee(fontSize: 18),
                    ),
                    Text(
                      marketsum[5],
                      style: GoogleFonts.aBeeZee(fontSize: 18),
                    ),
                  ],
                ),
                const Divider(),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      marketsum[6],
                      style: GoogleFonts.aBeeZee(fontSize: 14),
                    ),
                    Text(
                      marketsum[7],
                      style: GoogleFonts.aBeeZee(fontSize: 18),
                    ),
                  ],
                ),
                const Divider(),
                (marketsum.length > 8)
                    ? Column(
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                marketsum[8],
                                style: GoogleFonts.aBeeZee(fontSize: 12),
                              ),
                              Text(
                                marketsum[9],
                                style: GoogleFonts.aBeeZee(fontSize: 14),
                              ),
                            ],
                          ),
                          const Divider(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                marketsum[10],
                                style: GoogleFonts.aBeeZee(fontSize: 12),
                              ),
                              Text(
                                marketsum[11],
                                style: GoogleFonts.aBeeZee(fontSize: 14),
                              ),
                            ],
                          ),
                        ],
                      )
                    : Container(
                        height: 1,
                      ),
                const Divider(),
              ],
            ),
          )
        : Container(
            decoration: BoxDecoration(
                color: Theme.of(context).bannerTheme.backgroundColor,
                border: Border.all(
                  color: const Color.fromARGB(255, 124, 56, 225),
                ),
                borderRadius: BorderRadius.circular(8)),
            child: const Center(
              child: Text("Loading"),
            ),
          );
  }

  togainerdata() {
    return (topgainer.length > 5)
        ? Container(
            decoration: BoxDecoration(
                color: Theme.of(context).bannerTheme.backgroundColor,
                border: Border.all(
                  color: const Color.fromARGB(255, 124, 56, 225),
                ),
                borderRadius: BorderRadius.circular(8)),
            padding: const EdgeInsets.only(left: 3, right: 3),
            child: Wrap(
              // main axis (rows or columns)
              children: <Widget>[
                Container(
                  color: Colors.green,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Top Gainers",
                          style: GoogleFonts.roboto(
                              fontSize: 20, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
                const Divider(),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Symbol",
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        "LTD",
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        "Point Change",
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        "%Change",
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                    ],
                  ),
                ),
                const Divider(
                  height: 8,
                  color: Colors.green,
                ),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        topgainer[1],
                        style: GoogleFonts.aBeeZee(fontSize: 16),
                      ),
                      Text(
                        topgainer[2],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topgainer[3],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topgainer[4],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                    ],
                  ),
                ),
                const Divider(),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        topgainer[5],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topgainer[6],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topgainer[7],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topgainer[8],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                    ],
                  ),
                ),
                const Divider(),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        topgainer[9],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topgainer[10],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topgainer[11],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topgainer[12],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                    ],
                  ),
                ),
                const Divider(),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        topgainer[13],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topgainer[14],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topgainer[15],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topgainer[16],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                    ],
                  ),
                ),
                const Divider(),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        topgainer[17],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topgainer[18],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topgainer[19],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topgainer[20],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                    ],
                  ),
                ),
                const Divider(),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        topgainer[21],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topgainer[22],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topgainer[23],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topgainer[24],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                    ],
                  ),
                ),
                const Divider(),
              ],
            ),
          )
        : Container(
            decoration: BoxDecoration(
                color: Theme.of(context).bannerTheme.backgroundColor,
                border: Border.all(
                  color: const Color.fromARGB(255, 124, 56, 225),
                ),
                borderRadius: BorderRadius.circular(8)),
            child: const Center(
              child: Text("Loading"),
            ),
          );
  }

  tolosserdata() {
    return (toplosser.length > 3)
        ? Container(
            decoration: BoxDecoration(
                color: Theme.of(context).bannerTheme.backgroundColor,
                border: Border.all(
                  color: const Color.fromARGB(255, 124, 56, 225),
                ),
                borderRadius: BorderRadius.circular(8)),
            padding: const EdgeInsets.only(left: 3, right: 3),
            child: Wrap(
              // main axis (rows or columns)
              children: <Widget>[
                Container(
                  color: Colors.red,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Top lossers",
                          style: GoogleFonts.roboto(
                              fontSize: 20, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
                const Divider(),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Symbol",
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        "LTD",
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        "Point Change",
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        "%Change",
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                    ],
                  ),
                ),
                const Divider(
                  height: 8,
                  color: Colors.green,
                ),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        toplosser[1],
                        style: GoogleFonts.aBeeZee(fontSize: 16),
                      ),
                      Text(
                        toplosser[2],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        toplosser[3],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        toplosser[4],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                    ],
                  ),
                ),
                const Divider(),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        toplosser[5],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        toplosser[6],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        toplosser[7],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        toplosser[8],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                    ],
                  ),
                ),
                const Divider(),
                (toplosser.length > 9)
                    ? Column(
                        children: [
                          Container(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  toplosser[9],
                                  style: GoogleFonts.aBeeZee(fontSize: 18),
                                ),
                                Text(
                                  toplosser[10],
                                  style: GoogleFonts.aBeeZee(fontSize: 18),
                                ),
                                Text(
                                  toplosser[11],
                                  style: GoogleFonts.aBeeZee(fontSize: 18),
                                ),
                                Text(
                                  toplosser[12],
                                  style: GoogleFonts.aBeeZee(fontSize: 18),
                                ),
                              ],
                            ),
                          ),
                          const Divider(),
                          Container(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  toplosser[13],
                                  style: GoogleFonts.aBeeZee(fontSize: 18),
                                ),
                                Text(
                                  toplosser[14],
                                  style: GoogleFonts.aBeeZee(fontSize: 18),
                                ),
                                Text(
                                  toplosser[15],
                                  style: GoogleFonts.aBeeZee(fontSize: 18),
                                ),
                                Text(
                                  toplosser[16],
                                  style: GoogleFonts.aBeeZee(fontSize: 18),
                                ),
                              ],
                            ),
                          ),
                          const Divider(),
                          Container(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  toplosser[17],
                                  style: GoogleFonts.aBeeZee(fontSize: 18),
                                ),
                                Text(
                                  toplosser[18],
                                  style: GoogleFonts.aBeeZee(fontSize: 18),
                                ),
                                Text(
                                  toplosser[19],
                                  style: GoogleFonts.aBeeZee(fontSize: 18),
                                ),
                                Text(
                                  toplosser[20],
                                  style: GoogleFonts.aBeeZee(fontSize: 18),
                                ),
                              ],
                            ),
                          ),
                          const Divider(),
                          Container(
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  toplosser[21],
                                  style: GoogleFonts.aBeeZee(fontSize: 18),
                                ),
                                Text(
                                  toplosser[22],
                                  style: GoogleFonts.aBeeZee(fontSize: 18),
                                ),
                                Text(
                                  toplosser[23],
                                  style: GoogleFonts.aBeeZee(fontSize: 18),
                                ),
                                Text(
                                  toplosser[24],
                                  style: GoogleFonts.aBeeZee(fontSize: 18),
                                ),
                              ],
                            ),
                          ),
                          const Divider(),
                        ],
                      )
                    : Container(
                        child: const Text("No Company"),
                      )
              ],
            ),
          )
        : Container(
            decoration: BoxDecoration(
                color: Theme.of(context).bannerTheme.backgroundColor,
                border: Border.all(
                  color: const Color.fromARGB(255, 124, 56, 225),
                ),
                borderRadius: BorderRadius.circular(8)),
            child: const Center(
              child: Text("Loading"),
            ),
          );
  }

  toshare() {
    return (topshares.length > 3)
        ? Container(
            decoration: BoxDecoration(
                color: Theme.of(context).bannerTheme.backgroundColor,
                border: Border.all(
                  color: const Color.fromARGB(255, 124, 56, 225),
                ),
                borderRadius: BorderRadius.circular(8)),
            padding: const EdgeInsets.only(left: 3, right: 3),
            child: Wrap(
              // main axis (rows or columns)
              children: <Widget>[
                Container(
                  color: Colors.blue,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Top Stocks By Share Traded",
                          style: GoogleFonts.roboto(
                              fontSize: 20, fontWeight: FontWeight.bold)),
                    ],
                  ),
                ),
                const Divider(),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        "Symbol",
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        "Share Traded",
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        "Closing Price",
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                    ],
                  ),
                ),
                const Divider(
                  height: 8,
                  color: Colors.green,
                ),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        topshares[1],
                        style: GoogleFonts.aBeeZee(fontSize: 16),
                      ),
                      Text(
                        topshares[2],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topshares[3],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                    ],
                  ),
                ),
                const Divider(),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        topshares[4],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topshares[5],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topshares[6],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                    ],
                  ),
                ),
                const Divider(),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        topshares[7],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topshares[8],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topshares[9],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                    ],
                  ),
                ),
                const Divider(),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        topshares[10],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topshares[11],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topshares[12],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                    ],
                  ),
                ),
                const Divider(),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        topshares[13],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topshares[14],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topshares[15],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                    ],
                  ),
                ),
                const Divider(),
                Container(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        topshares[16],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topshares[17],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                      Text(
                        topshares[18],
                        style: GoogleFonts.aBeeZee(fontSize: 18),
                      ),
                    ],
                  ),
                ),
                const Divider(),
              ],
            ),
          )
        : Container(
            decoration: BoxDecoration(
                color: Theme.of(context).bannerTheme.backgroundColor,
                border: Border.all(
                  color: const Color.fromARGB(255, 124, 56, 225),
                ),
                borderRadius: BorderRadius.circular(8)),
            child: const Center(
              child: Text("Loading"),
            ),
          );
  }

  AppBar meroappbar(BuildContext context) {
    return AppBar(
      backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      elevation: 0,

      systemOverlayStyle: SystemUiOverlayStyle(
          statusBarColor: Theme.of(context).scaffoldBackgroundColor,
          statusBarIconBrightness:
              Provider.of<ThemeProvider>(context).isDarkMode
                  ? Brightness.light
                  : Brightness.dark),
      iconTheme: Theme.of(context).iconTheme,

      leadingWidth: 25,

      title:
          Text("Share Alpha", style: Theme.of(context).textTheme.headlineLarge),

      //

      // actionsIconTheme: IconThemeData(color: AppColor.iconColor),
    );
  }

  topCardView(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 2),
      padding: const EdgeInsets.all(8.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5),
        border: Border.all(color: Theme.of(context).shadowColor, width: 0.2),
        color: Theme.of(context).cardColor,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Today Info
          Text(npToday, style: Theme.of(context).textTheme.headline1),
          const SizedBox(height: 10),

          /*--------------------------------*/
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Current Time

                  // Today's event
                  Text(
                    event,
                    style: const TextStyle(fontSize: 20),
                  ),

                  // Today's english date
                  Text(
                    engDateToday,
                    style: GoogleFonts.mulish(
                        fontSize: 16, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(height: 4),

                  Text(
                    livetime,
                    style: GoogleFonts.roboto(fontSize: 16),
                  ),

                  // Weather Info
                  Row(
                    children: [
                      Icon(
                        Icons.circle,
                        size: 16,
                        color: (market[0] == "Market Open")
                            ? Colors.green
                            : Colors.red,
                      ),
                      const SizedBox(width: 10),
                      Text(
                        market[0],
                        style: GoogleFonts.mulish(
                            fontSize: 20, fontWeight: FontWeight.bold),
                      )
                    ],
                  ),
                  (market[0] == "Market Open")
                      ? Padding(
                          padding: const EdgeInsets.only(top: 5, left: 25),
                          child: Container(
                            decoration: BoxDecoration(
                                border: Border.all(
                              color: const Color.fromARGB(255, 124, 56, 225),
                            )),
                            child: Row(
                              children: [
                                const Icon(
                                  Icons.circle,
                                  size: 16,
                                  color: Colors.red,
                                ),
                                AnimatedTextKit(
                                  onTap: () {
                                    _interstitialAd?.show();
                                    Navigator.push(context,
                                        MaterialPageRoute(builder: (context) {
                                      return const Companylive();
                                    }));
                                  },
                                  animatedTexts: [
                                    ColorizeAnimatedText("Live Market Data",
                                        textStyle:
                                            const TextStyle(fontSize: 20),
                                        colors: [
                                          Colors.red,
                                          Colors.greenAccent,
                                          Colors.purple,
                                        ]),
                                  ],
                                  isRepeatingAnimation: true,
                                  repeatForever: true,
                                ),
                              ],
                            ),
                          ),
                        )
                      : Container(
                          child: Text(date[0]),
                        ),
                ],
              ),

              // My Notes
              Container(
                width: 0.28 * MediaQuery.of(context).size.width,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(5),
                  color: Theme.of(context).scaffoldBackgroundColor,
                ),
                child: GestureDetector(
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => const Note()),
                    );
                  },
                  child: Column(
                    children: [
                      // Add Notes text
                      Container(
                        padding: const EdgeInsets.all(5.0),
                        width: double.maxFinite,
                        decoration: BoxDecoration(
                          borderRadius: const BorderRadius.only(
                              topLeft: Radius.circular(6),
                              topRight: Radius.circular(6)),
                          color: Theme.of(context).primaryColor,
                        ),
                        child: const Text(
                          "+ My Note",
                          style: TextStyle(color: Colors.white),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      const SizedBox(height: 10),

                      // Note set for today
                      const Text("Add note for today",
                          style: TextStyle(fontSize: 12)),
                      const SizedBox(height: 15),

                      // View Notes
                      Container(
                        padding: const EdgeInsets.all(5.0),
                        width: double.maxFinite,
                        decoration: const BoxDecoration(
                          border: Border(
                            top: BorderSide(color: Colors.grey, width: 0.2),
                          ),
                        ),
                        child: const Text(
                          "View Notes \u2192",
                          style: TextStyle(color: Colors.blue, fontSize: 12),
                          textAlign: TextAlign.center,
                        ),
                      )
                    ],
                  ),
                ),
              )
            ],
          )
        ],
      ),
    );
  }

  notification(BuildContext context) {
    return Container(
      color: Theme.of(context).highlightColor,
      padding: const EdgeInsets.all(15),
      child: Row(
        children: [
          // Message Button
          ElevatedButton.icon(
            onPressed: () {
              if (notifi['open'].toString() == 'news') {
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return const News(
                    nepse: 'Samachar',
                  );
                }));
              } else if (notifi['open'] == 'ipo') {
                Navigator.push(context, MaterialPageRoute(builder: (context) {
                  return IPO();
                }));
              } else if (notifi['open'] == 'link') {
                launch(notifi['url']);
              } else {}
            },
            label: Text(
              'Open',
              style: Theme.of(context).textTheme.headline6,
            ),
            icon:
                const Icon(Icons.link, color: Color.fromARGB(103, 45, 8, 180)),
            style: ElevatedButton.styleFrom(
              primary: Theme.of(context).scaffoldBackgroundColor,
              elevation: 0.5,
              padding: const EdgeInsets.symmetric(horizontal: 20),
              side: const BorderSide(width: 0.7, color: Colors.black),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30.0)),
            ),
          ),
          const SizedBox(width: 30),

          Flexible(
              child: (notifi == null)
                  ? const Text("Warm Welcome!")
                  : Text.rich(
                      TextSpan(
                        children: [
                          TextSpan(
                              text: '${notifi['msg']}',
                              style: const TextStyle(
                                  fontSize: 15, fontWeight: FontWeight.w400)),
                          const WidgetSpan(
                              child: Icon(Icons.smart_button, size: 16)),
                        ],
                      ),
                    ))
        ],
      ),
    );
  }

  hamroServices() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10),
      width: double.infinity,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(left: 10),
            child: Text(
              "Hamro Services",
              style: Theme.of(context).textTheme.headline2,
            ),
          ),
          GridView.count(
            padding: const EdgeInsets.only(top: 10),
            crossAxisCount: 3,
            shrinkWrap: true,
            childAspectRatio: 1.5,
            physics: const NeverScrollableScrollPhysics(),
            children: [
              Container(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: const Color.fromARGB(255, 124, 56, 225),
                    ),
                    borderRadius: BorderRadius.circular(25)),
                child: Column(children: [
                  IconButton(
                    onPressed: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context) {
                        return Company(
                            date: (market[0] == "Market Close")
                                ? date[0]
                                : market[0]);
                      }));
                    },
                    icon: const Icon(Icons.live_tv),
                  ),
                  const Text("Market"),
                ]),
              ),
              Container(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: const Color.fromARGB(255, 124, 56, 225),
                    ),
                    borderRadius: BorderRadius.circular(25)),
                child: Column(children: [
                  IconButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const WebviewPage()),
                      );
                    },
                    icon: const Icon(Icons.home_work),
                  ),
                  const Text("Aplha"),
                ]),
              ),
              Container(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: const Color.fromARGB(255, 124, 56, 225),
                    ),
                    borderRadius: BorderRadius.circular(25)),
                child: Column(children: [
                  IconButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const Unicode()),
                      );
                    },
                    icon: const Icon(Icons.baby_changing_station),
                  ),
                  const Text("Uinicode"),
                ]),
              ),
              Container(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: const Color.fromARGB(255, 124, 56, 225),
                    ),
                    borderRadius: BorderRadius.circular(25)),
                child: Column(children: [
                  IconButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const WebviewPage(
                                  link: "https://meroshare.ngp.com.np/",
                                  name: "Bulk IPO Apply - Share Alpha",
                                )),
                      );
                    },
                    icon: const Icon(Icons.baby_changing_station),
                  ),
                  const Text("IPO Apply"),
                ]),
              ),
              Container(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: const Color.fromARGB(255, 124, 56, 225),
                    ),
                    borderRadius: BorderRadius.circular(25)),
                child: Column(children: [
                  IconButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => const WebviewPage(
                                    link:
                                        "https://nepsealpha.com/trading/chart",
                                    name: "Nepse Chart",
                                  )),
                        );
                      },
                      icon: const Icon(Icons.line_axis)),
                  const Text("Tech. Chart"),
                ]),
              ),
              Container(
                decoration: BoxDecoration(
                    border: Border.all(
                      color: const Color.fromARGB(255, 124, 56, 225),
                    ),
                    borderRadius: BorderRadius.circular(25)),
                child: Column(children: [
                  IconButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => const WebviewPage(
                                  link:
                                      "https://nepsealpha.com/widget/buy-sell",
                                  name: "Share Calculator",
                                )),
                      );
                    },
                    icon: const Icon(Icons.calculate),
                  ),
                  const Text("Share Calculator"),
                ]),
              ),
            ],
          ),
        ],
      ),
    );
  }

  promotions(BuildContext context) {
    return Container(
        padding: const EdgeInsets.all(13),
        height: _bannerAd.size.height.toDouble(),
        width: MediaQuery.of(context).size.width,
        color: Theme.of(context).bannerTheme.backgroundColor,
        child: (isBannerLoad == true)
            ? AdWidget(ad: _bannerAd)
            : const Center(child: Text("Promote with us.")));
  }

  moreFeatures() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(
                  padding: const EdgeInsets.all(7),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: const Icon(
                    Icons.dashboard_rounded,
                    color: Colors.white,
                    size: 20,
                  ),
                ),
                const SizedBox(height: 10),
                Text(
                  "More Features",
                  style: Theme.of(context).textTheme.headline2,
                ),
              ]),
              GestureDetector(
                child: const Icon(Icons.info, size: 25),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) {
                    return const About();
                  }));
                },
              ),
            ],
          ),
          const SizedBox(height: 5),

          // -------------------------------- //
          const Text(
            "Other services we provide",
            style: TextStyle(fontWeight: FontWeight.w400, fontSize: 15),
          ),
          const SizedBox(height: 10),

          // -------------------------------- //
          const MoreFeaturesWidget(),
        ],
      ),
    );
  }
}
