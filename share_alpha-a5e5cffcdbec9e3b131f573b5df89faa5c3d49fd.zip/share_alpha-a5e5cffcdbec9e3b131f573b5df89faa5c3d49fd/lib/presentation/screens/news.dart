import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:html/parser.dart';
import 'package:http/http.dart' as http;
import 'package:html/dom.dart' as dom;
import 'package:share_alpha/presentation/screens/newsdetail.dart';

class News extends StatefulWidget {
  final nepse;
  const News({this.nepse, Key? key}) : super(key: key);

  @override
  State<News> createState() => _NewsState();
}

class _NewsState extends State<News> {
  List<String> news = [
    "Fetching Fresh News...",
  ];
  List<String> newsdate = [
    "Fetching Fresh News...",
  ];
  List<String> imgnews = [
    "Fetching Fresh News...",
  ];
  List<String> link = [
    "Fetching Fresh News...",
  ];

  Future getnews() async {
    final response = await http
        .get(Uri.parse("https://www.nepalipaisa.com/Stock-Market.aspx"));
    dom.Document html = parse(response.body);

    final nep =
        html.querySelectorAll(".Shareul")[0].querySelectorAll("div > h2");
    final dat =
        html.querySelectorAll(".Shareul")[0].querySelectorAll("div > p");
    final imgnep =
        html.querySelectorAll(".Shareul")[0].querySelectorAll(" a > img");
    final ln =
        html.querySelectorAll(".Shareul")[0].querySelectorAll("li > div > a");

    setState(() {
      news = nep.map((element) => element.text.trim().toUpperCase()).toList();
      newsdate = dat.map((element) => element.text.trim().toString()).toList();
      imgnews = imgnep.map((element) => element.attributes['src']!).toList();
      link = ln.map((element) => element.attributes['href']!).toList();
    });
  }

  @override
  void initState() {
    getnews();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Column(
          children: [
            const Text("Share Khabar"),
            Row(
              children: [
                (widget.nepse[0] == "Market Close")
                    ? const Icon(Icons.tv_off)
                    : const Icon(Icons.tv),
                const SizedBox(
                  width: 5,
                ),
                Text(widget.nepse[0]),
              ],
            ),
          ],
        ),
      ),
      body: RefreshIndicator(
        onRefresh: getnews,
        child: (imgnews.length > 5)
            ? ListView.separated(
                shrinkWrap: true,
                separatorBuilder: (context, index) {
                  return const Divider();
                },
                itemCount: imgnews.length,
                itemBuilder: ((context, index) {
                  return Container(
                    decoration: const BoxDecoration(),
                    child: Padding(
                      padding: const EdgeInsets.only(left: 8.0, right: 8),
                      child: GestureDetector(
                        onTap: () {
                          Navigator.push(context,
                              MaterialPageRoute(builder: ((context) {
                            return Newsdetail(
                              link: link[index],
                              img: "https://www.nepalipaisa.com" +
                                  imgnews[index],
                              tittle: news[index],
                            );
                          })));
                        },
                        child: Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(right: 10.0),
                              child: Container(
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        color: const Color.fromARGB(
                                            255, 100, 42, 172))),
                                child: Image.network(
                                  "https://www.nepalipaisa.com" +
                                      imgnews[index],
                                ),
                              ),
                            ),
                            Expanded(
                                child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  news[index],
                                  style: GoogleFonts.roboto(
                                      fontWeight: FontWeight.bold),
                                ),
                                Text(
                                  newsdate[index],
                                  style: GoogleFonts.roboto(color: Colors.grey),
                                ),
                                (index == imgnews.length - 1)
                                    ? const Padding(
                                        padding: EdgeInsets.only(top: 20),
                                        child: Text("No more fresh data"))
                                    : Container()
                              ],
                            ))
                          ],
                        ),
                      ),
                    ),
                  );
                }))
            : ListView.separated(
                shrinkWrap: true,
                separatorBuilder: (context, index) {
                  return const Divider();
                },
                itemCount: 10,
                itemBuilder: ((context, index) {
                  return Container(
                    decoration: const BoxDecoration(),
                    child: Padding(
                      padding: const EdgeInsets.only(left: 8.0, right: 8),
                      child: Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(right: 10.0),
                            child: Container(
                              decoration: BoxDecoration(
                                  border: Border.all(
                                      color: const Color.fromARGB(
                                          255, 100, 42, 172))),
                              child: Image.asset("assets/images/loading.gif"),
                              width: 150,
                            ),
                          ),
                          Expanded(
                              child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                "तातो तातो खबर तानदै । क्रिप्य Wait गर्नुहोस्",
                                style: GoogleFonts.roboto(
                                    fontWeight: FontWeight.bold),
                              ),
                              Text(
                                "Share Alpha",
                                style: GoogleFonts.roboto(color: Colors.grey),
                              )
                            ],
                          ))
                        ],
                      ),
                    ),
                  );
                })),
      ),
    );
  }
}
