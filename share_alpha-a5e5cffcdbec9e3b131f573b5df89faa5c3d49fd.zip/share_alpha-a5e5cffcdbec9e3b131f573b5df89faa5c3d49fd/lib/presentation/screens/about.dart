import 'package:flutter/material.dart';

import 'package:url_launcher/url_launcher_string.dart';

class About extends StatefulWidget {
  const About({Key? key}) : super(key: key);

  @override
  State<About> createState() => _AboutState();
}

class _AboutState extends State<About> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("About Us"),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
          child: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          const CircleAvatar(
            minRadius: 40,
            maxRadius: 70,
            backgroundImage: AssetImage(
              "assets/logo.jpg",
            ),
          ),
          const Text("Share Alpha"),
          const Divider(),
          Row(
            children: [
              const Icon(
                Icons.circle,
              ),
              Container(
                  decoration: BoxDecoration(
                    border: Border.all(width: 3, color: Colors.blueGrey),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  margin: const EdgeInsets.only(left: 6),
                  padding: const EdgeInsets.all(8),
                  child: const Text(
                    "About The App",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  )),
              Expanded(
                  child: Container(
                color: Colors.blueGrey,
                height: 3,
              ))
            ],
          ),
          const SizedBox(
            height: 10,
          ),
          const Card(
              color: Color.fromARGB(255, 227, 226, 226),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(8))),
              child: ListTile(
                leading: Icon(Icons.info),
                title: Text("Develop by NGP Developer"),
                subtitle: Text("www.ngp.com.np"),
              )),
          const SizedBox(
            height: 10,
          ),
          const Card(
              color: Color.fromARGB(255, 227, 226, 226),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(8))),
              child: ListTile(
                leading: Icon(Icons.info),
                title: Text("Design by us"),
              )),
          const SizedBox(
            height: 10,
          ),
          const Card(
              color: Color.fromARGB(255, 227, 226, 226),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(8))),
              child: ListTile(
                leading: Icon(Icons.info),
                title: Text("Legalase by GooglePlay"),
              )),
          const SizedBox(
            height: 10,
          ),
          GestureDetector(
            onTap: () {
              launchUrlString("https://privacypolicy.ngp.com.np/sharealpha");
            },
            child: const Card(
                color: Color.fromARGB(255, 227, 226, 226),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.all(Radius.circular(8))),
                child: ListTile(
                  leading: Icon(Icons.info),
                  title: Text(
                    "Privacy Policy",
                    style: TextStyle(color: Colors.blue),
                  ),
                )),
          ),
          const SizedBox(
            height: 10,
          ),
          const SizedBox(
            height: 10,
          ),
          Row(
            children: [
              const Icon(
                Icons.circle,
                color: Colors.blueGrey,
              ),
              Container(
                  decoration: BoxDecoration(
                    border: Border.all(width: 3, color: Colors.blueGrey),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  margin: const EdgeInsets.only(left: 6),
                  padding: const EdgeInsets.all(8),
                  child: const Text(
                    "Source",
                    style: TextStyle(fontWeight: FontWeight.bold),
                  )),
              Expanded(
                  child: Container(
                color: Colors.blueGrey,
                height: 3,
              ))
            ],
          ),
          const SizedBox(
            height: 10,
          ),
          const Card(
              color: Color.fromARGB(255, 227, 226, 226),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(8))),
              child: ListTile(
                leading: Icon(Icons.web),
                title: Text("Nepse Data "),
                subtitle: Text("nepalstock"),
              )),
          const SizedBox(
            height: 10,
          ),
          const Card(
              color: Color.fromARGB(255, 227, 226, 226),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.all(Radius.circular(8))),
              child: ListTile(
                leading: Icon(Icons.web_sharp),
                title: Text("News and other data"),
                subtitle: Text("nepsealpha,nepalipaisa,meroshare"),
              )),
          const SizedBox(
            height: 10,
          ),
        ],
      )),
    );
  }
}
