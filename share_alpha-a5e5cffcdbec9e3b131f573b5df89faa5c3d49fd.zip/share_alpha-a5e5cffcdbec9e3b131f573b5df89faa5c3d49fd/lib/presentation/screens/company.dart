import 'dart:convert';

import 'package:api_cache_manager/models/cache_db_model.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:http/http.dart' as http;
import 'package:api_cache_manager/api_cache_manager.dart';

class Company extends StatefulWidget {
  final date;
  const Company({Key? key, this.date}) : super(key: key);

  @override
  State<Company> createState() => _CompanyState();
}

class _CompanyState extends State<Company> {
  List company = [];
  List searchcompany = [];
  bool search = false;

  Future refresh() async {
    var res = await http
        .get(Uri.parse("https://nepalstockapi.herokuapp.com/allprice.php"));
    if (res.statusCode == 200) {
      APICacheDBModel cacheDBModel =
          APICacheDBModel(key: "company", syncData: res.body);
      await APICacheManager().addCacheData(cacheDBModel);
      setState(() {
        company = jsonDecode(res.body) as List;
        searchcompany = jsonDecode(res.body) as List;
      });
    }
  }

  Future getData() async {
    var isData = await APICacheManager().isAPICacheKeyExist("company");
    if (!isData) {
      var res = await http
          .get(Uri.parse("https://nepalstockapi.herokuapp.com/allprice.php"));

      APICacheDBModel cacheDBModel =
          APICacheDBModel(key: "company", syncData: res.body);
      await APICacheManager().addCacheData(cacheDBModel);

      setState(() {
        company = jsonDecode(res.body) as List;
        searchcompany = jsonDecode(res.body) as List;
      });
    } else {
      var casData = await APICacheManager().getCacheData("company");
      setState(() {
        company = jsonDecode(casData.syncData) as List;
        searchcompany = jsonDecode(casData.syncData) as List;
      });
    }
  }

  fltcompany(String value) {
    if (value.isEmpty) {
      searchcompany = company;
    }
    searchcompany = company
        .where((element) => element["tradecompany"]
            .toString()
            .toLowerCase()
            .contains(value.toLowerCase()))
        .toList();
  }

  @override
  void initState() {
    super.initState();
    getData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          leading: (search == true)
              ? const Icon(Icons.search)
              : IconButton(
                  onPressed: () {
                    Navigator.pop(context);
                  },
                  icon: const Icon(Icons.arrow_back)),
          actions: [
            (search == false)
                ? IconButton(
                    onPressed: () {
                      setState(() {
                        search = true;
                      });
                    },
                    icon: const Icon(Icons.search))
                : IconButton(
                    onPressed: () {
                      setState(() {
                        search = false;
                        setState(() {
                          searchcompany = company;
                        });
                      });
                    },
                    icon: const Icon(Icons.cancel))
          ],
          toolbarHeight: 70,
          centerTitle: true,
          title: (search == false)
              ? Column(
                  children: [
                    const Text("Nepse"),
                    Text(
                      widget.date,
                      style: const TextStyle(fontSize: 14),
                    ),
                  ],
                )
              : TextField(
                  onChanged: (value) {
                    setState(() {});
                    fltcompany(value);
                  },
                  onSubmitted: (value) {
                    fltcompany(value);
                    setState(() {
                      search = false;
                    });
                  },
                  decoration: const InputDecoration(
                      label: Text("search company by name")),
                )),
      body: (company.isEmpty)
          ? Center(
              child: CircularProgressIndicator(
                color: Theme.of(context).appBarTheme.backgroundColor,
              ),
            )
          : RefreshIndicator(
              onRefresh: getData,
              child: Column(
                children: [
                  //color: (nepse[4].contains("-")) ? Colors.red : Colors.green,

                  Expanded(
                    child: ListView.separated(
                        shrinkWrap: true,
                        itemBuilder: (context, index) {
                          return GestureDetector(
                            onTap: () {
                              // showModalBottomSheet(
                              //     context: context,
                              //     builder: (builder) {
                              //       return Container(
                              //         decoration: BoxDecoration(
                              //           color: (company[11 * index + 4]
                              //                   .contains("-"))
                              //               ? Colors.red
                              //               : (company[11 * index + 4] ==
                              //                       '0.00')
                              //                   ? Colors.blue
                              //                   : Colors.green,
                              //           border: Border.all(
                              //             color: const Color.fromARGB(
                              //                 255, 124, 56, 225),
                              //           ),
                              //         ),
                              //         height:
                              //             MediaQuery.of(context).size.height *
                              //                 0.30,

                              //         // ignore: prefer_const_constructors
                              //         child: Column(
                              //           children: [
                              //             Row(
                              //               mainAxisAlignment:
                              //                   MainAxisAlignment.spaceBetween,
                              //               children: [
                              //                 Text(company[11 * index + 1],
                              //                     textScaleFactor: 2,
                              //                     style: const TextStyle(
                              //                         fontWeight:
                              //                             FontWeight.bold)),
                              //                 Text(
                              //                     "LTP" +
                              //                         company[11 * index + 2],
                              //                     textScaleFactor: 2,
                              //                     style: const TextStyle(
                              //                         fontWeight:
                              //                             FontWeight.bold)),
                              //               ],
                              //             ),
                              //             const Divider(),
                              //             Container(
                              //               color: Theme.of(context)
                              //                   .bannerTheme
                              //                   .backgroundColor,
                              //               child: Column(
                              //                 children: [
                              //                   Row(
                              //                     mainAxisAlignment:
                              //                         MainAxisAlignment
                              //                             .spaceBetween,
                              //                     children: const [
                              //                       Text(
                              //                         "LTV",
                              //                         textScaleFactor: 1.5,
                              //                       ),
                              //                       Text("Point change",
                              //                           textScaleFactor: 1.5),
                              //                       Text("%Change",
                              //                           textScaleFactor: 1.5),
                              //                       Text("Open",
                              //                           textScaleFactor: 1.5),
                              //                     ],
                              //                   ),
                              //                   Row(
                              //                     mainAxisAlignment:
                              //                         MainAxisAlignment
                              //                             .spaceBetween,
                              //                     children: [
                              //                       Text(
                              //                           company[11 * index + 3],
                              //                           textScaleFactor: 1.5),
                              //                       Text(
                              //                           company[11 * index + 4],
                              //                           textScaleFactor: 1.5),
                              //                       Text(
                              //                           company[11 * index + 5],
                              //                           textScaleFactor: 1.5),
                              //                       Text(
                              //                           company[11 * index + 6],
                              //                           textScaleFactor: 1.5),
                              //                     ],
                              //                   )
                              //                 ],
                              //               ),
                              //             ),
                              //             const SizedBox(
                              //               height: 20,
                              //             ),
                              //             Container(
                              //               color: Theme.of(context)
                              //                   .bannerTheme
                              //                   .backgroundColor,
                              //               child: Column(
                              //                 children: [
                              //                   Row(
                              //                     mainAxisAlignment:
                              //                         MainAxisAlignment
                              //                             .spaceBetween,
                              //                     children: const [
                              //                       Text(
                              //                         "High",
                              //                         textScaleFactor: 1.5,
                              //                       ),
                              //                       Text("Low",
                              //                           textScaleFactor: 1.5),
                              //                       Text("Volume",
                              //                           textScaleFactor: 1.5),
                              //                       Text("Prev.Closing",
                              //                           textScaleFactor: 1.5),
                              //                     ],
                              //                   ),
                              //                   Row(
                              //                     mainAxisAlignment:
                              //                         MainAxisAlignment
                              //                             .spaceBetween,
                              //                     children: [
                              //                       Text(
                              //                           company[11 * index + 7],
                              //                           textScaleFactor: 1.5),
                              //                       Text(
                              //                           company[11 * index + 8],
                              //                           textScaleFactor: 1.5),
                              //                       Text(
                              //                           company[11 * index + 9],
                              //                           textScaleFactor: 1.5),
                              //                       Text(
                              //                           company[
                              //                               11 * index + 10],
                              //                           textScaleFactor: 1.5),
                              //                     ],
                              //                   )
                              //                 ],
                              //               ),
                              //             ),
                              //           ],
                              //         ),
                              //       );
                              //     });
                            },
                            child: Container(
                              color: (searchcompany[index]["difference"]
                                      .contains("-"))
                                  ? Colors.red
                                  : (searchcompany[1]["difference"] == "00.00")
                                      ? Colors.blue
                                      : Colors.green,
                              child: Wrap(
                                spacing: 8, // gap between adjacent chips
                                runSpacing: 4.0, // gap between lines
                                direction: Axis
                                    .horizontal, // main axis (rows or columns)
                                children: <Widget>[
                                  Text(
                                    searchcompany[index]["tradecompany"],
                                    style: GoogleFonts.roboto(
                                        fontSize: 20,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  Text(
                                    "Open = ".toUpperCase() +
                                        (searchcompany[index]
                                            ["previousclosing"]),
                                    style: const TextStyle(
                                        fontWeight: FontWeight.bold),
                                  ),
                                  Text("No of transaction = ".toUpperCase() +
                                      (searchcompany[index]
                                          ["nooftransaction"])),
                                  Text("tradedshares = ".toUpperCase() +
                                      (searchcompany[index]["tradedshares"])),
                                  Text("amount = ".toUpperCase() +
                                      (searchcompany[index]["amount"])),
                                  Text("High = ".toUpperCase() +
                                      (searchcompany[index]["maxprice"])),
                                  Text("Low = ".toUpperCase() +
                                      (searchcompany[index]["minprice"])),
                                  Text("difference = ".toUpperCase() +
                                      (searchcompany[index]["difference"])),
                                  Text(
                                    "closingprice = ".toUpperCase() +
                                        (searchcompany[index]["closingprice"]),
                                    style: const TextStyle(
                                        fontWeight: FontWeight.bold),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                        separatorBuilder: (context, index) {
                          return const Divider();
                        },
                        itemCount: searchcompany.length),
                  ),
                ],
              ),
            ),
    );
  }
}
