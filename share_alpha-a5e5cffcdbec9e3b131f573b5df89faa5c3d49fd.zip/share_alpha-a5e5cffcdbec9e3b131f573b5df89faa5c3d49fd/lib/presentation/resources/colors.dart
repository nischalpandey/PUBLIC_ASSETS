import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

class MyThemes {
  //-------------light THEME SETTINGS----
  static final lightTheme = ThemeData(
    brightness: Brightness.light,
    scaffoldBackgroundColor: Colors.white,
    appBarTheme: (const AppBarTheme(
        backgroundColor: Color.fromARGB(255, 124, 56, 225),
        systemOverlayStyle: SystemUiOverlayStyle(
            statusBarColor: Color.fromARGB(255, 124, 56, 225)))),
    primaryColor: const Color.fromARGB(255, 124, 56, 225),
    shadowColor: Colors.grey,
    textTheme: TextTheme(
      headlineLarge: GoogleFonts.mulish(
          fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black),
      headline1: GoogleFonts.mulish(
          fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black),
      headline2: const TextStyle(
          fontWeight: FontWeight.bold, fontSize: 17, color: Colors.black),
      headline3: const TextStyle(
          fontWeight: FontWeight.w500, fontSize: 15, color: Colors.black),
    ),
    iconTheme: const IconThemeData(color: Color(0xFF606060)),
    cardColor: Colors.grey[50],
    bannerTheme:
        const MaterialBannerThemeData(backgroundColor: Color(0xFFe2e2e2)),
    highlightColor: Colors.orange[50],
  );

  //-------------DARK THEME SETTINGS----
  static final darkTheme = ThemeData(
    appBarTheme: const AppBarTheme(
        systemOverlayStyle: SystemUiOverlayStyle(
            statusBarColor: Color.fromARGB(255, 109, 104, 104)),
        backgroundColor: Color.fromARGB(255, 109, 104, 104)),
    brightness: Brightness.dark,
    scaffoldBackgroundColor: const Color(0xFF333336),
    shadowColor: Colors.black54,
    primaryColor: Colors.black,
    textTheme: TextTheme(
      headlineLarge: GoogleFonts.mulish(
          fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
      headline1: GoogleFonts.mulish(
          fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
      headline2: const TextStyle(
          fontWeight: FontWeight.bold, fontSize: 17, color: Colors.white),
      headline3: const TextStyle(
          fontWeight: FontWeight.w500, fontSize: 15, color: Colors.white),
    ),
    iconTheme: const IconThemeData(color: Colors.purpleAccent),
    cardColor: const Color(0xFF2c2c2c),
    bannerTheme: const MaterialBannerThemeData(backgroundColor: Colors.black54),
    highlightColor: const Color(0xFF222323),
  );
}
