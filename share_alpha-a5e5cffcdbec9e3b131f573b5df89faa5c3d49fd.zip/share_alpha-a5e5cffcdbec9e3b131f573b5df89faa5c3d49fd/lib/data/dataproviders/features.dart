class MoreFeatures {
  List features = [
    {
      "image": "assets/images/mero.png",
      "text": "Real Portfolio",
      "link": "https://meroshare.cdsc.com.np/"
    },
    {
      "image": "assets/images/clac.jpg",
      "text": "Right share claculator",
      "link": "https://nepsealpha.com/widget/right-share-adjustment"
    },
    {
      "image": "assets/images/features_3.jpg",
      "text": "EMI Calculator",
      "link": "https://www.sharesansar.com/emi-calculator"
    },
    {
      "image": "assets/images/clac.jpg",
      "text": "Bonus Share Adjusment",
      "link": "https://nepsealpha.com/widget/bonus-share-adjustment"
    },
    {"image": "assets/images/mero.png", "text": "IPO Reasult", "link": "open"},
    {
      "image": "assets/images/clac.jpg",
      "text": "Fibonacci Calculator",
      "link": "https://nepsealpha.com/widget/fibonacci-calc"
    },
  ];
}
