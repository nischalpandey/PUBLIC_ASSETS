import 'dart:convert';

import 'package:http/http.dart' as http;

class GetCompany {
  String url = "https://nepalstockapi.herokuapp.com/allprice.php";

  getapicompany() async {
    try {
      var res = await http.get(Uri.parse(url));
      if (res.statusCode == 200) {
        return jsonDecode(res.toString());
      } else {
        return "Nepse server Error!";
      }
    } catch (e) {
      return "Internet error";
    }
  }
}
