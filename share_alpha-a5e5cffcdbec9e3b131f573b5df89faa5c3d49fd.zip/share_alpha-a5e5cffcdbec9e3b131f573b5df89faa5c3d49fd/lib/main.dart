import 'package:flutter/material.dart';

import 'package:provider/provider.dart';
import 'package:share_alpha/data/models/theme_model.dart';
import 'package:share_alpha/presentation/resources/colors.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:share_alpha/presentation/screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  MobileAds.instance.initialize();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (context) => ThemeProvider(),
      builder: (context, _) => Consumer<ThemeProvider>(
        builder: (context, themeData, child) {
          return MaterialApp(
            title: 'Share Alpha',
            debugShowCheckedModeBanner: false,
            theme: MyThemes.lightTheme,
            darkTheme: MyThemes.darkTheme,
            // themeMode: ThemeMode.dark,
            themeMode: themeData.themeMode,
            initialRoute: "/",
            routes: {
              "/": (context) => const HomePage(),
            },
          );
        },
      ),
    );
  }
}
